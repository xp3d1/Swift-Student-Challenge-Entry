public class Gene{
    public var innovationNumber:Int?;
    public init(innovation: Int){
        innovationNumber = innovation
    }
}
