import Foundation
import SwiftUI

public class UserSettings: ObservableObject {
    public init() {}
    @Published public var page = 0
}
